# Demo Pack: Expected Deliverables

Upload any file into the dashboard.

## What should appear

### Who
- Top targeted users table (failures).
- Top source IPs table (failures).

### When
- Timeline chart (events per minute, split by outcome).

### How
- For Linux SSH: src_ip, user, outcome extracted.
- For Windows CSV: EventID maps to success/failure.

### Possible attacks
- demo_auth_linux.log
  - password_spray from 198.51.100.77 (many usernames)
  - bruteforce on admin from 203.0.113.10 (many failures in 5m)
  - success_after_failures for admin (accept after failures)
- demo_windows_security.csv
  - success_after_failures for ACME\jane
  - password_spray-like pattern from 203.0.113.50 across many users
- demo_cloud_auth.jsonl
  - success_after_failures for alex@acme.example
  - password_spray from 203.0.113.99 across many users

## Notes
- demo_mixed_generic.log is mostly "unknown" outcome because generic fallback is minimal.
- Use it to show the system still ingests unknown formats without breaking.
