import random
import json
from datetime import datetime, timedelta

# ============================================================================
# MYSQL / MARIADB LOG GENERATORS
# ============================================================================

def generate_mysql_error_logs(count=100):
    """Generate MySQL/MariaDB error logs"""
    error_templates = [
        ("010048", "Table '{table}' doesn't exist"),
        ("001146", "Table '{database}.{table}' doesn't exist"),
        ("001054", "Unknown column '{column}' in '{clause}'"),
        ("001064", "You have an error in your SQL syntax"),
        ("001045", "Access denied for user '{user}'@'{host}' (using password: {pwd})"),
        ("002013", "Lost connection to MySQL server during query"),
        ("002006", "MySQL server has gone away"),
        ("001062", "Duplicate entry '{value}' for key '{key}'"),
        ("001205", "Lock wait timeout exceeded; try restarting transaction"),
        ("001213", "Deadlock found when trying to get lock; try restarting transaction"),
    ]
    
    tables = ["users", "orders", "products", "sessions", "payments"]
    databases = ["production", "staging", "commerce"]
    columns = ["id", "user_id", "email", "created_at", "status"]
    users = ["root", "app_user", "admin", "webapp"]
    hosts = ["localhost", "192.168.1.100", "10.0.0.45"]
    
    logs = []
    base_time = datetime(2024, 1, 1, 0, 0, 0)
    
    for i in range(count):
        base_time += timedelta(seconds=random.randint(1, 300))
        timestamp = base_time.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
        thread_id = random.randint(1, 500)
        
        error_code, template = random.choice(error_templates)
        msg = template.format(
            table=random.choice(tables),
            database=random.choice(databases),
            column=random.choice(columns),
            clause="field list",
            user=random.choice(users),
            host=random.choice(hosts),
            pwd=random.choice(["YES", "NO"]),
            value=random.randint(1, 99999),
            key="PRIMARY"
        )
        
        logs.append(f"{timestamp} {thread_id} [ERROR] [MY-{error_code}] [Server] {msg}")
    
    return logs

def generate_mysql_query_logs(count=100):
    """Generate MySQL/MariaDB query logs"""
    queries = [
        "SELECT * FROM users WHERE id = {id}",
        "INSERT INTO orders (user_id, total) VALUES ({uid}, {amount})",
        "UPDATE products SET stock = {stock} WHERE id = {id}",
        "DELETE FROM sessions WHERE created_at < '{date}'",
        "SELECT COUNT(*) FROM payments WHERE status = 'completed'",
        "SELECT u.name, o.total FROM users u JOIN orders o ON u.id = o.user_id",
        "CREATE INDEX idx_user_email ON users(email)",
        "ALTER TABLE products ADD COLUMN description TEXT",
    ]
    
    logs = []
    base_time = datetime(2024, 1, 1, 0, 0, 0)
    
    for i in range(count):
        base_time += timedelta(seconds=random.randint(1, 60))
        timestamp = base_time.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
        thread_id = random.randint(1, 500)
        
        query = random.choice(queries).format(
            id=random.randint(1, 1000),
            uid=random.randint(1, 500),
            amount=round(random.uniform(10, 1000), 2),
            stock=random.randint(0, 100),
            date=(datetime.now() - timedelta(days=30)).strftime("%Y-%m-%d")
        )
        
        logs.append(f"{timestamp} {thread_id} Query {query};")
    
    return logs

def generate_mysql_slow_query_logs(count=100):
    """Generate MySQL/MariaDB slow query logs"""
    queries = [
        "SELECT * FROM users JOIN orders ON users.id = orders.user_id WHERE orders.created_at > '2024-01-01'",
        "SELECT COUNT(*) FROM products p JOIN inventory i ON p.id = i.product_id GROUP BY p.category",
        "UPDATE orders SET status = 'completed' WHERE id IN (SELECT order_id FROM payments WHERE processed = 1)",
        "DELETE FROM logs WHERE created_at < DATE_SUB(NOW(), INTERVAL 90 DAY)",
    ]
    
    users = ["app_user", "webapp", "admin", "readonly"]
    hosts = ["app-server-01", "web-server-02", "localhost"]
    ips = ["192.168.1.100", "10.0.0.45", "172.16.0.23"]
    
    logs = []
    base_time = datetime(2024, 1, 1, 0, 0, 0)
    
    for i in range(count):
        base_time += timedelta(seconds=random.randint(60, 600))
        timestamp = base_time.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
        
        user = random.choice(users)
        host = random.choice(hosts)
        ip = random.choice(ips)
        query_time = round(random.uniform(5.0, 120.0), 2)
        rows_examined = random.randint(10000, 1000000)
        
        log = f"# Time: {timestamp}\n"
        log += f"# User@Host: {user}[{user}] @ {host} [{ip}]\n"
        log += f"# Query_time: {query_time} Rows_examined: {rows_examined}\n"
        log += f"{random.choice(queries)};"
        
        logs.append(log)
    
    return logs

# ============================================================================
# POSTGRESQL LOG GENERATORS
# ============================================================================

def generate_postgresql_error_logs(count=100):
    """Generate PostgreSQL error logs"""
    error_messages = [
        "relation \"{table}\" does not exist",
        "column \"{column}\" does not exist",
        "syntax error at or near \"{keyword}\"",
        "permission denied for table {table}",
        "duplicate key value violates unique constraint \"{constraint}\"",
        "deadlock detected",
        "could not serialize access due to concurrent update",
        "out of memory",
        "connection to client lost",
        "database \"{database}\" does not exist",
    ]
    
    tables = ["users", "orders", "products", "sessions"]
    columns = ["id", "email", "created_at", "user_id"]
    keywords = ["SELECT", "FROM", "WHERE", ")", ";"]
    constraints = ["users_pkey", "users_email_key", "orders_user_id_fkey"]
    databases = ["production", "staging", "test_db"]
    
    logs = []
    base_time = datetime(2024, 1, 1, 0, 0, 0)
    
    for i in range(count):
        base_time += timedelta(seconds=random.randint(1, 300))
        timestamp = base_time.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
        timezone = "UTC"
        pid = random.randint(1000, 9999)
        
        msg = random.choice(error_messages).format(
            table=random.choice(tables),
            column=random.choice(columns),
            keyword=random.choice(keywords),
            constraint=random.choice(constraints),
            database=random.choice(databases)
        )
        
        logs.append(f"{timestamp} {timezone} [{pid}] ERROR: {msg}")
    
    return logs

def generate_postgresql_auth_logs(count=100):
    """Generate PostgreSQL auth logs"""
    users = ["postgres", "app_user", "admin", "readonly"]
    databases = ["production", "staging", "analytics"]
    
    logs = []
    base_time = datetime(2024, 1, 1, 0, 0, 0)
    
    for i in range(count):
        base_time += timedelta(seconds=random.randint(10, 600))
        timestamp = base_time.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
        timezone = "UTC"
        pid = random.randint(1000, 9999)
        
        user = random.choice(users)
        db = random.choice(databases)
        
        logs.append(f"{timestamp} {timezone} [{pid}] LOG: connection authorized: user={user} database={db}")
    
    return logs

def generate_postgresql_statement_logs(count=100):
    """Generate PostgreSQL statement logs"""
    statements = [
        "SELECT * FROM users WHERE id = {id}",
        "INSERT INTO orders (user_id, total) VALUES ({uid}, {amount})",
        "UPDATE products SET stock = stock - {qty} WHERE id = {id}",
        "DELETE FROM sessions WHERE last_activity < NOW() - INTERVAL '1 day'",
        "CREATE INDEX idx_orders_user_id ON orders(user_id)",
    ]
    
    logs = []
    base_time = datetime(2024, 1, 1, 0, 0, 0)
    
    for i in range(count):
        base_time += timedelta(seconds=random.randint(1, 60))
        timestamp = base_time.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
        timezone = "UTC"
        pid = random.randint(1000, 9999)
        
        stmt = random.choice(statements).format(
            id=random.randint(1, 1000),
            uid=random.randint(1, 500),
            amount=round(random.uniform(10, 1000), 2),
            qty=random.randint(1, 10)
        )
        
        logs.append(f"{timestamp} {timezone} [{pid}] STATEMENT: {stmt};")
    
    return logs

# ============================================================================
# ORACLE LOG GENERATORS
# ============================================================================

def generate_oracle_alert_logs(count=100):
    """Generate Oracle alert logs"""
    errors = [
        ("00600", "internal error code, arguments: [{arg1}], [{arg2}], [{arg3}]"),
        ("01555", "snapshot too old: rollback segment number {num} with name \"{name}\" too small"),
        ("01652", "unable to extend temp segment by {size} in tablespace {ts}"),
        ("00054", "resource busy and acquire with NOWAIT specified or timeout expired"),
        ("01017", "invalid username/password; logon denied"),
        ("12154", "TNS:could not resolve the connect identifier specified"),
        ("00257", "archiver error. Connect internal only, until freed"),
        ("03113", "end-of-file on communication channel"),
        ("01578", "ORACLE data block corrupted (file # {file}, block # {block})"),
        ("27301", "OS system dependent operation:open failed with status: {status}"),
    ]
    
    logs = []
    base_time = datetime(2024, 1, 1, 0, 0, 0)
    
    for i in range(count):
        base_time += timedelta(seconds=random.randint(1, 300))
        timestamp = base_time.strftime("%a %b %d %H:%M:%S %Y")
        
        error_code, template = random.choice(errors)
        msg = template.format(
            arg1=random.randint(1000, 9999),
            arg2=random.randint(1000, 9999),
            arg3=random.randint(1000, 9999),
            num=random.randint(1, 100),
            name=f"RBS_{random.randint(1, 50)}",
            size=random.randint(128, 1024),
            ts=random.choice(["TEMP", "USERS", "SYSTEM"]),
            file=random.randint(1, 50),
            block=random.randint(1000, 99999),
            status=random.randint(1, 100)
        )
        
        logs.append(f"{timestamp}\nORA-{error_code}: {msg}")
    
    return logs

def generate_oracle_listener_logs(count=100):
    """Generate Oracle listener logs"""
    services = ["ORCL", "PROD", "DEV", "TEST"]
    ips = ["192.168.1.100", "10.0.0.45", "172.16.0.23"]
    ports = [1521, 1522, 1523]
    statuses = ["0", "12541", "12514"]
    
    logs = []
    base_time = datetime(2024, 1, 1, 0, 0, 0)
    
    for i in range(count):
        base_time += timedelta(seconds=random.randint(1, 120))
        timestamp = base_time.strftime("%d-%b-%Y %H:%M:%S")
        
        service = random.choice(services)
        ip = random.choice(ips)
        port = random.choice(ports)
        status = random.choice(statuses)
        
        logs.append(f"{timestamp} * (CONNECT_DATA=(SERVICE_NAME={service})) * (ADDRESS=(PROTOCOL=tcp)(HOST={ip})(PORT={port})) * establish * {service} * {status}")
    
    return logs

def generate_oracle_audit_logs(count=100):
    """Generate Oracle audit logs"""
    actions = ["SELECT", "INSERT", "UPDATE", "DELETE", "CREATE TABLE", "DROP TABLE", "ALTER TABLE"]
    users = ["SYSTEM", "APP_USER", "ADMIN", "SCOTT"]
    objects = ["USERS", "ORDERS", "PRODUCTS", "EMPLOYEES", "DEPARTMENTS"]
    
    logs = []
    base_time = datetime(2024, 1, 1, 0, 0, 0)
    
    for i in range(count):
        base_time += timedelta(seconds=random.randint(1, 180))
        timestamp = base_time.strftime("%Y-%m-%d %H:%M:%S")
        
        log = f"Audit record generated at {timestamp}\n"
        log += f"ACTION : {random.choice(actions)}\n"
        log += f"USERID : {random.choice(users)}\n"
        log += f"OBJ$NAME : {random.choice(objects)}"
        
        logs.append(log)
    
    return logs

# ============================================================================
# SQL SERVER LOG GENERATORS
# ============================================================================

def generate_sqlserver_error_logs(count=100):
    """Generate SQL Server error logs"""
    errors = [
        (18456, 16, 1, "Login failed for user '{user}'"),
        (1205, 13, 1, "Transaction (Process ID {pid}) was deadlocked on lock resources with another process"),
        (8621, 16, 1, "The query processor ran out of stack space during query optimization"),
        (701, 17, 1, "There is insufficient system memory in resource pool '{pool}' to run this query"),
        (9002, 17, 1, "The transaction log for database '{db}' is full"),
        (823, 24, 2, "The operating system returned error {oserror} to SQL Server during a read"),
        (17065, 16, 1, "SQL Server Assertion: File: <{file}>, line={line}"),
        (3314, 21, 1, "During undoing of a logged operation in database '{db}', an error occurred"),
    ]
    
    users = ["sa", "app_user", "admin", "NT AUTHORITY\\SYSTEM"]
    databases = ["master", "production", "staging", "tempdb"]
    pools = ["default", "internal"]
    
    logs = []
    base_time = datetime(2024, 1, 1, 0, 0, 0)
    
    for i in range(count):
        base_time += timedelta(seconds=random.randint(1, 300))
        timestamp = base_time.strftime("%Y-%m-%d %H:%M:%S.%f")[:-4]
        
        error_code, severity, state, template = random.choice(errors)
        msg = template.format(
            user=random.choice(users),
            pid=random.randint(50, 999),
            pool=random.choice(pools),
            db=random.choice(databases),
            oserror=random.randint(1, 100),
            file="<unknown>",
            line=random.randint(100, 9999)
        )
        
        logs.append(f"{timestamp} Server Error: {error_code}, Severity: {severity}, State: {state}.")
    
    return logs

def generate_sqlserver_audit_logs(count=100):
    """Generate SQL Server audit logs"""
    actions = ["SELECT", "INSERT", "UPDATE", "DELETE", "EXECUTE", "CREATE_TABLE", "DROP_TABLE"]
    users = ["sa", "app_user", "admin", "readonly"]
    databases = ["master", "production", "staging", "analytics"]
    statements = [
        "SELECT * FROM Users WHERE ID = {id}",
        "INSERT INTO Orders VALUES ({id}, {uid}, {amount})",
        "UPDATE Products SET Stock = {stock} WHERE ID = {id}",
        "DELETE FROM Sessions WHERE Created < DATEADD(day, -30, GETDATE())",
        "EXEC sp_GetUserInfo @UserID = {id}",
    ]
    
    logs = []
    
    for i in range(count):
        action_id = random.choice(actions)
        user = random.choice(users)
        db = random.choice(databases)
        stmt = random.choice(statements).format(
            id=random.randint(1, 1000),
            uid=random.randint(1, 500),
            amount=round(random.uniform(10, 1000), 2),
            stock=random.randint(0, 100)
        )
        
        logs.append(f"action_id={action_id} session_server_principal_name={user} database_name={db} statement={stmt}")
    
    return logs

def generate_sqlserver_transaction_logs(count=100):
    """Generate SQL Server transaction logs"""
    operations = ["LOP_BEGIN_XACT", "LOP_COMMIT_XACT", "LOP_INSERT_ROWS", "LOP_DELETE_ROWS", 
                  "LOP_MODIFY_ROW", "LOP_CREATE_INDEX", "LOP_ABORT_XACT"]
    
    logs = []
    
    for i in range(count):
        file_id = random.randint(1, 10)
        offset = random.randint(1000, 999999)
        slot = random.randint(1, 50)
        operation = random.choice(operations)
        
        logs.append(f"LSN: ({file_id}:{offset}:{slot}) Operation: {operation}")
    
    return logs

# ============================================================================
# MONGODB LOG GENERATORS
# ============================================================================

def generate_mongodb_server_logs(count=100):
    """Generate MongoDB server logs (JSON)"""
    severities = ["I", "W", "E", "F"]
    components = ["NETWORK", "STORAGE", "QUERY", "COMMAND", "REPL", "ACCESS"]
    messages = [
        "Connection accepted from {ip}:{port}",
        "Connection ended",
        "Error connecting to replica set member",
        "Successfully authenticated",
        "Failed to authenticate user",
        "Slow query detected",
        "Index build completed",
        "Collection scan detected",
    ]
    
    ips = ["192.168.1.100", "10.0.0.45", "172.16.0.23"]
    ports = [27017, 27018, 27019]
    
    logs = []
    base_time = datetime(2024, 1, 1, 0, 0, 0)
    
    for i in range(count):
        base_time += timedelta(seconds=random.randint(1, 120))
        timestamp = base_time.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
        
        log = {
            "t": {"$date": timestamp},
            "s": random.choice(severities),
            "c": random.choice(components),
            "msg": random.choice(messages).format(
                ip=random.choice(ips),
                port=random.choice(ports)
            ),
            "attr": {
                "remote": f"{random.choice(ips)}:{random.choice(ports)}"
            }
        }
        
        logs.append(json.dumps(log, indent=2))
    
    return logs

def generate_mongodb_audit_logs(count=100):
    """Generate MongoDB audit logs (JSON)"""
    audit_types = ["authenticate", "authCheck", "createCollection", "createDatabase", 
                   "dropCollection", "dropDatabase", "insert", "update", "remove"]
    users = ["admin", "app_user", "readonly", "backup"]
    databases = ["production", "staging", "analytics", "admin"]
    commands = ["find", "insert", "update", "delete", "aggregate", "createIndexes"]
    
    logs = []
    base_time = datetime(2024, 1, 1, 0, 0, 0)
    
    for i in range(count):
        base_time += timedelta(seconds=random.randint(1, 180))
        timestamp = base_time.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
        
        log = {
            "atype": random.choice(audit_types),
            "ts": {"$date": timestamp},
            "users": [{
                "user": random.choice(users),
                "db": random.choice(databases)
            }],
            "param": {
                "command": random.choice(commands)
            }
        }
        
        logs.append(json.dumps(log, indent=2))
    
    return logs

# ============================================================================
# MAIN EXECUTION
# ============================================================================

def main():

    print("=" * 80)
    print("MULTI-DATABASE LOG GENERATOR")
    print("=" * 80)
    print()
    
    # MySQL/MariaDB Logs
    print("### MYSQL/MARIADB - ERROR LOGS ###")
    print("-" * 80)
    with open('Database Logs/logs/MySQL-Error.log',"w",newline='') as fout:
        for log in generate_mysql_error_logs(1000):
            fout.write(log)
            fout.write("\n")
               
        
    print("### MYSQL/MARIADB - QUERY LOGS ###")
    print("-" * 80)
    for log in generate_mysql_query_logs(50):
        print(log)
    print()
    
    print("### MYSQL/MARIADB - SLOW QUERY LOGS ###")
    print("-" * 80)
    for log in generate_mysql_slow_query_logs(30):
        print(log)
        print()
    
    # PostgreSQL Logs
    print("### POSTGRESQL - ERROR LOGS ###")
    print("-" * 80)
    for log in generate_postgresql_error_logs(50):
        print(log)
    print()
    
    print("### POSTGRESQL - AUTH LOGS ###")
    print("-" * 80)
    for log in generate_postgresql_auth_logs(30):
        print(log)
    print()
    
    print("### POSTGRESQL - STATEMENT LOGS ###")
    print("-" * 80)
    for log in generate_postgresql_statement_logs(50):
        print(log)
    print()
    
    # Oracle Logs
    print("### ORACLE - ALERT LOGS ###")
    print("-" * 80)
    for log in generate_oracle_alert_logs(50):
        print(log)
        print()
    
    print("### ORACLE - LISTENER LOGS ###")
    print("-" * 80)
    for log in generate_oracle_listener_logs(30):
        print(log)
    print()
    
    print("### ORACLE - AUDIT LOGS ###")
    print("-" * 80)
    for log in generate_oracle_audit_logs(30):
        print(log)
        print()
    
    # SQL Server Logs
    print("### SQL SERVER - ERROR LOGS ###")
    print("-" * 80)
    for log in generate_sqlserver_error_logs(50):
        print(log)
    print()
    
    print("### SQL SERVER - AUDIT LOGS ###")
    print("-" * 80)
    for log in generate_sqlserver_audit_logs(30):
        print(log)
    print()
    
    print("### SQL SERVER - TRANSACTION LOGS ###")
    print("-" * 80)
    for log in generate_sqlserver_transaction_logs(30):
        print(log)
    print()
    
    # MongoDB Logs
    print("### MONGODB - SERVER LOGS (JSON) ###")
    print("-" * 80)
    for log in generate_mongodb_server_logs(30):
        print(log)
    print()
    
    print("### MONGODB - AUDIT LOGS (JSON) ###")
    print("-" * 80)
    for log in generate_mongodb_audit_logs(30):
        print(log)
    print()
    
    print("=" * 80)
    print("LOG GENERATION COMPLETE")
    print("=" * 80)

if __name__ == "__main__":
    main()