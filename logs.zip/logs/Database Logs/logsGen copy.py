import random
import json
from datetime import datetime, timedelta

# ============================================================================
# MYSQL / MARIADB LOG GENERATORS
# ============================================================================

def generate_mysql_error_logs(count=100):
    """Generate MySQL/MariaDB error logs"""
    error_templates = [
        ("010048", "Table '{table}' doesn't exist"),
        ("001146", "Table '{database}.{table}' doesn't exist"),
        ("001054", "Unknown column '{column}' in '{clause}'"),
        ("001064", "You have an error in your SQL syntax"),
        ("001045", "Access denied for user '{user}'@'{host}' (using password: {pwd})"),
        ("002013", "Lost connection to MySQL server during query"),
        ("002006", "MySQL server has gone away"),
        ("001062", "Duplicate entry '{value}' for key '{key}'"),
        ("001205", "Lock wait timeout exceeded; try restarting transaction"),
        ("001213", "Deadlock found when trying to get lock; try restarting transaction"),
    ]
    
    tables = ["users", "orders", "products", "sessions", "payments"]
    databases = ["production", "staging", "commerce"]
    columns = ["id", "user_id", "email", "created_at", "status"]
    users = ["root", "app_user", "admin", "webapp"]
    hosts = ["localhost", "192.168.1.100", "10.0.0.45"]
    
    logs = []
    base_time = datetime(2024, 1, 1, 0, 0, 0)
    
    for i in range(count):
        base_time += timedelta(seconds=random.randint(1, 300))
        timestamp = base_time.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
        thread_id = random.randint(1, 500)
        
        error_code, template = random.choice(error_templates)
        msg = template.format(
            table=random.choice(tables),
            database=random.choice(databases),
            column=random.choice(columns),
            clause="field list",
            user=random.choice(users),
            host=random.choice(hosts),
            pwd=random.choice(["YES", "NO"]),
            value=random.randint(1, 99999),
            key="PRIMARY"
        )
        
        logs.append(f"{timestamp} {thread_id} [ERROR] [MY-{error_code}] [Server] {msg}")
    
    return logs

def generate_mysql_query_logs(count=100):
    """Generate MySQL/MariaDB query logs"""
    
    # Tables and databases
    tables = ["users", "orders", "products", "sessions", "payments", "customers", "inventory", "transactions", "logs", "accounts"]
    databases = ["production", "staging", "commerce", "analytics", "crm"]
    columns = ["id", "user_id", "email", "created_at", "updated_at", "status", "name", "price", "quantity", "total", "amount", "description"]
    
    # SELECT query templates
    select_queries = [
        "SELECT * FROM {table} WHERE id = {id}",
        "SELECT * FROM {table} WHERE {column} = '{value}'",
        "SELECT {col1}, {col2}, {col3} FROM {table}",
        "SELECT COUNT(*) FROM {table} WHERE {column} = '{value}'",
        "SELECT * FROM {table} WHERE id IN ({id1}, {id2}, {id3})",
        "SELECT * FROM {table} WHERE {column} > {num}",
        "SELECT * FROM {table} WHERE {column} BETWEEN {num1} AND {num2}",
        "SELECT * FROM {table} WHERE {column} LIKE '%{value}%'",
        "SELECT * FROM {table} ORDER BY {column} DESC LIMIT {limit}",
        "SELECT * FROM {table} WHERE {column} IS NOT NULL",
        "SELECT u.*, o.* FROM {table1} u JOIN {table2} o ON u.id = o.user_id",
        "SELECT {column}, COUNT(*) as count FROM {table} GROUP BY {column}",
        "SELECT * FROM {table} WHERE {column} = '{value}' AND {column2} = {num}",
        "SELECT AVG({column}) FROM {table}",
        "SELECT SUM({column}) FROM {table} WHERE {column2} = '{value}'",
        "SELECT DISTINCT {column} FROM {table}",
        "SELECT * FROM {table} WHERE DATE({column}) = '{date}'",
        "SELECT * FROM {table} WHERE {column} IN (SELECT {column} FROM {table2})",
    ]
    
    # INSERT query templates
    insert_queries = [
        "INSERT INTO {table} ({col1}, {col2}) VALUES ('{val1}', '{val2}')",
        "INSERT INTO {table} ({col1}, {col2}, {col3}) VALUES ({num1}, '{val}', {num2})",
        "INSERT INTO {table} SET {col1} = '{val}', {col2} = {num}",
        "INSERT INTO {table} ({col1}) VALUES ('{val}')",
        "INSERT INTO {table} ({col1}, {col2}, {col3}) VALUES ('{val1}', {num}, NOW())",
        "INSERT IGNORE INTO {table} ({col1}, {col2}) VALUES ('{val}', {num})",
    ]
    
    # UPDATE query templates
    update_queries = [
        "UPDATE {table} SET {column} = '{value}' WHERE id = {id}",
        "UPDATE {table} SET {col1} = '{val}', {col2} = {num} WHERE id = {id}",
        "UPDATE {table} SET {column} = {column} + {num} WHERE id = {id}",
        "UPDATE {table} SET {column} = '{value}' WHERE {column2} = {num}",
        "UPDATE {table} SET {column} = NOW() WHERE id = {id}",
        "UPDATE {table} SET {col1} = '{val}' WHERE {col2} IN ({id1}, {id2})",
        "UPDATE {table} SET {column} = CASE WHEN {column2} > {num} THEN '{val1}' ELSE '{val2}' END WHERE id = {id}",
    ]
    
    # DELETE query templates
    delete_queries = [
        "DELETE FROM {table} WHERE id = {id}",
        "DELETE FROM {table} WHERE {column} = '{value}'",
        "DELETE FROM {table} WHERE {column} < {num}",
        "DELETE FROM {table} WHERE {column} IN ({id1}, {id2}, {id3})",
        "DELETE FROM {table} WHERE DATE({column}) < '{date}'",
        "DELETE FROM {table} WHERE {column} IS NULL",
    ]
    
    # DDL query templates
    ddl_queries = [
        "CREATE INDEX idx_{column} ON {table}({column})",
        "ALTER TABLE {table} ADD COLUMN {column} VARCHAR(255)",
        "ALTER TABLE {table} MODIFY COLUMN {column} TEXT",
        "DROP INDEX idx_{column} ON {table}",
        "TRUNCATE TABLE {table}",
        "CREATE TABLE {table}_backup AS SELECT * FROM {table}",
    ]
    
    # Transaction queries
    transaction_queries = [
        "START TRANSACTION",
        "COMMIT",
        "ROLLBACK",
        "SET AUTOCOMMIT = 0",
        "SET AUTOCOMMIT = 1",
    ]
    
    # Admin queries
    admin_queries = [
        "SHOW TABLES",
        "SHOW DATABASES",
        "DESCRIBE {table}",
        "SHOW CREATE TABLE {table}",
        "SHOW INDEX FROM {table}",
        "SHOW PROCESSLIST",
        "SHOW STATUS",
        "SHOW VARIABLES LIKE '%max_connections%'",
        "ANALYZE TABLE {table}",
        "OPTIMIZE TABLE {table}",
        "FLUSH TABLES",
        "SHOW TABLE STATUS LIKE '{table}'",
    ]
    
    # All query templates combined
    all_queries = (
        select_queries * 50 +  # 50% SELECT queries
        insert_queries * 20 +  # 20% INSERT queries
        update_queries * 15 +  # 15% UPDATE queries
        delete_queries * 10 +  # 10% DELETE queries
        ddl_queries * 3 +      # 3% DDL queries
        transaction_queries * 1 +  # 1% Transaction queries
        admin_queries * 1      # 1% Admin queries
    )
    
    logs = []
    base_time = datetime(2024, 1, 1, 0, 0, 0)
    
    for i in range(count):
        base_time += timedelta(seconds=random.randint(1, 60))
        timestamp = base_time.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
        thread_id = random.randint(1, 500)
        
        query_template = random.choice(all_queries)
        
        # Generate query with random values
        query = query_template.format(
            table=random.choice(tables),
            table1=random.choice(tables),
            table2=random.choice(tables),
            database=random.choice(databases),
            column=random.choice(columns),
            column2=random.choice(columns),
            col1=random.choice(columns),
            col2=random.choice(columns),
            col3=random.choice(columns),
            id=random.randint(1, 10000),
            id1=random.randint(1, 1000),
            id2=random.randint(1, 1000),
            id3=random.randint(1, 1000),
            num=random.randint(1, 1000),
            num1=random.randint(1, 100),
            num2=random.randint(100, 1000),
            value=random.choice(["active", "pending", "completed", "failed", "processing", "test", "example"]),
            val=random.choice(["active", "inactive", "pending", "verified", "admin", "user"]),
            val1=random.choice(["completed", "active", "yes", "true", "enabled"]),
            val2=random.choice(["pending", "inactive", "no", "false", "disabled"]),
            limit=random.choice([10, 20, 50, 100]),
            date=(datetime(2024, 1, 1) + timedelta(days=random.randint(0, 365))).strftime("%Y-%m-%d")
        )
        
        logs.append(f"{timestamp} {thread_id} Query {query};")
    
    return logs

def generate_mysql_slow_query_logs(count=100):
    """Generate MySQL/MariaDB slow query logs"""
    
    # SQL query templates
    queries = [
        "SELECT * FROM {table} WHERE {column} = {value}",
        "SELECT * FROM {table1} JOIN {table2} ON {table1}.id = {table2}.{fk} WHERE {table1}.{column} > '{date}'",
        "SELECT COUNT(*) FROM {table1} t1 JOIN {table2} t2 ON t1.id = t2.{fk} WHERE t1.status = '{status}' GROUP BY t1.{column}",
        "UPDATE {table} SET {column} = '{value}' WHERE id IN (SELECT {fk} FROM {table2} WHERE {column2} = {value2})",
        "DELETE FROM {table} WHERE {column} < DATE_SUB(NOW(), INTERVAL {days} DAY)",
        "SELECT {column1}, {column2}, COUNT(*) as cnt FROM {table} GROUP BY {column1}, {column2} HAVING cnt > {num} ORDER BY cnt DESC LIMIT {limit}",
        "SELECT t1.*, t2.{column} FROM {table1} t1 LEFT JOIN {table2} t2 ON t1.id = t2.{fk} WHERE t1.{column2} LIKE '%{pattern}%'",
        "INSERT INTO {table} ({column1}, {column2}, {column3}) SELECT {column1}, {column2}, {column3} FROM {table2} WHERE {column} > {value}",
        "SELECT DISTINCT {column1}, {column2} FROM {table1} WHERE {column3} IN (SELECT id FROM {table2} WHERE status = '{status}')",
        "UPDATE {table1} t1 JOIN {table2} t2 ON t1.id = t2.{fk} SET t1.{column} = t2.{column2} WHERE t2.updated_at > '{date}'",
        "SELECT {table1}.*, {table2}.{column} FROM {table1} INNER JOIN {table2} ON {table1}.{fk} = {table2}.id WHERE {table2}.{column2} BETWEEN {val1} AND {val2}",
        "DELETE t1 FROM {table1} t1 LEFT JOIN {table2} t2 ON t1.{fk} = t2.id WHERE t2.id IS NULL",
        "SELECT {column}, SUM({column2}) as total, AVG({column3}) as average FROM {table} WHERE {column4} = '{status}' GROUP BY {column} ORDER BY total DESC",
        "CREATE INDEX idx_{table}_{column} ON {table}({column})",
        "ALTER TABLE {table} ADD COLUMN {column} VARCHAR(255) DEFAULT NULL",
        "SELECT * FROM {table} WHERE MATCH({column1}, {column2}) AGAINST('{pattern}' IN BOOLEAN MODE)",
        "REPLACE INTO {table} ({column1}, {column2}, {column3}) VALUES ({val1}, '{val2}', {val3})",
        "SELECT {column1}, GROUP_CONCAT({column2} SEPARATOR ', ') as items FROM {table1} JOIN {table2} ON {table1}.id = {table2}.{fk} GROUP BY {column1}",
    ]
    
    # Data pools
    tables = ["users", "orders", "products", "sessions", "payments", "customers", "inventory", "transactions", "logs", "reports", "invoices", "shipments"]
    columns = ["id", "user_id", "email", "created_at", "updated_at", "status", "amount", "quantity", "name", "description", "price", "total", "product_id", "order_id", "customer_id"]
    users = ["root", "app_user", "admin", "webapp", "readonly", "backup_user", "replication", "analytics_user"]
    hosts = ["localhost", "app-server-01", "web-server-02", "db-client-03", "analytics-01", "batch-processor"]
    ips = ["127.0.0.1", "192.168.1.100", "10.0.0.45", "172.16.0.23", "192.168.10.50", "10.20.30.40"]
    statuses = ["active", "pending", "completed", "cancelled", "processing", "failed", "approved", "rejected"]
    
    logs = []
    base_time = datetime(2024, 1, 1, 0, 0, 0)
    
    for i in range(count):
        # Increment time randomly (slow queries happen less frequently)
        base_time += timedelta(seconds=random.randint(30, 600))
        timestamp = base_time.strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
        
        # Random user, host, and IP
        user = random.choice(users)
        host = random.choice(hosts)
        ip = random.choice(ips)
        
        # Random query time (slow queries: 5.0 to 300.0 seconds)
        query_time = round(random.uniform(5.0, 300.0), 2)
        
        # Random rows examined (higher for slow queries)
        rows_examined = random.randint(10000, 10000000)
        
        # Generate SQL statement
        query_template = random.choice(queries)
        sql_statement = query_template.format(
            table=random.choice(tables),
            table1=random.choice(tables),
            table2=random.choice([t for t in tables if t != tables[0]]),
            column=random.choice(columns),
            column1=random.choice(columns),
            column2=random.choice(columns),
            column3=random.choice(columns),
            column4=random.choice(columns),
            fk=random.choice(["user_id", "order_id", "product_id", "customer_id"]),
            value=random.randint(1, 100000),
            value2=random.randint(1, 100000),
            val1=random.randint(1, 1000),
            val2=random.choice(statuses),
            val3=round(random.uniform(10.0, 1000.0), 2),
            date=(datetime.now() - timedelta(days=random.randint(1, 365))).strftime("%Y-%m-%d"),
            days=random.randint(30, 365),
            status=random.choice(statuses),
            num=random.randint(5, 100),
            limit=random.randint(10, 1000),
            pattern=random.choice(["search", "test", "prod", "data", "user"])
        )
        
        # Format log entry
        log_entry = f"# Time: {timestamp}\n"
        log_entry += f"# User@Host: {user}[{user}] @ {host} [{ip}]\n"
        log_entry += f"# Query_time: {query_time} Rows_examined: {rows_examined}\n"
        log_entry += f"{sql_statement};"
        
        logs.append(log_entry)
    
    return logs

# ============================================================================
# POSTGRESQL LOG GENERATORS
# ============================================================================

def generate_postgresql_error_logs(count=1000):
    """Generate PostgreSQL error logs"""
    from datetime import datetime, timedelta
    import random
    
    error_templates = [
        ("42P01", "relation \"{table}\" does not exist"),
        ("42703", "column \"{column}\" does not exist"),
        ("42601", "syntax error at or near \"{token}\""),
        ("28P01", "password authentication failed for user \"{user}\""),
        ("08006", "connection to server at \"{host}\", port {port} failed: Connection refused"),
        ("08003", "connection does not exist"),
        ("08000", "server closed the connection unexpectedly"),
        ("23505", "duplicate key value violates unique constraint \"{constraint}\""),
        ("23503", "insert or update on table \"{table}\" violates foreign key constraint \"{constraint}\""),
        ("40P01", "deadlock detected"),
        ("55P03", "lock timeout exceeded"),
        ("53300", "too many connections for database \"{database}\""),
        ("53400", "configuration parameter \"{param}\" cannot be changed now"),
        ("25P02", "current transaction is aborted, commands ignored until end of transaction block"),
        ("22P02", "invalid input syntax for type {datatype}: \"{value}\""),
        ("42883", "function {function}({args}) does not exist"),
        ("42804", "datatype mismatch at or near \"{location}\""),
        ("22001", "value too long for type character varying({length})"),
        ("57014", "canceling statement due to user request"),
        ("57P03", "cannot drop the currently open database"),
    ]
    
    tables = ["users", "orders", "products", "sessions", "payments", "transactions", "inventory", "customers", "accounts"]
    columns = ["id", "user_id", "email", "created_at", "updated_at", "status", "price", "quantity", "name"]
    tokens = ["\"", "SELECT", "FROM", "WHERE", ")", ";", "UPDATE", "INSERT"]
    users = ["postgres", "app_user", "admin", "dbuser", "webapp", "readonly"]
    hosts = ["localhost", "192.168.1.100", "10.0.0.45", "db-primary.internal", "db-replica-01.internal"]
    databases = ["production", "staging", "commerce", "analytics", "main_db"]
    constraints = ["users_pkey", "orders_user_id_fkey", "products_unique_sku", "sessions_pkey", "payments_order_id_fkey"]
    datatypes = ["integer", "timestamp", "uuid", "numeric", "jsonb"]
    functions = ["calculate_total", "update_inventory", "get_user_stats", "process_payment"]
    params = ["max_connections", "shared_buffers", "work_mem", "maintenance_work_mem"]
    
    log_levels = ["ERROR", "FATAL", "PANIC"]
    
    logs = []
    base_time = datetime(2024, 1, 1, 0, 0, 0)
    
    for i in range(count):
        base_time += timedelta(seconds=random.randint(1, 300))
        timestamp = base_time.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3] + " UTC"
        
        pid = random.randint(1000, 9999)
        level = random.choice(log_levels)
        error_code, template = random.choice(error_templates)
        
        # Format the error message based on template
        msg = template.format(
            table=random.choice(tables),
            column=random.choice(columns),
            token=random.choice(tokens),
            user=random.choice(users),
            host=random.choice(hosts),
            port=5432,
            database=random.choice(databases),
            constraint=random.choice(constraints),
            datatype=random.choice(datatypes),
            value=random.choice(["abc123", "not_a_number", "invalid", str(random.randint(1, 99999))]),
            function=random.choice(functions),
            args=random.choice(["integer", "text, integer", "uuid, timestamp"]),
            location=random.choice(["line 1", "position " + str(random.randint(1, 100))]),
            length=random.choice([50, 100, 255]),
            param=random.choice(params)
        )
        
        # PostgreSQL log format: timestamp [pid] user@database level: SQLSTATE[code]: message
        user = random.choice(users)
        database = random.choice(databases)
        
        log_entry = f"{timestamp} [{pid}] {user}@{database} {level}: {error_code}: {msg}"
        logs.append(log_entry)
    
    return logs


def generate_postgres_auth_logs(count=1000):
    """
    Generate realistic PostgreSQL connection authorized logs
    Format: <timestamp> <timezone> [<pid>] LOG:  connection authorized: user=<user> database=<db>
    """
    # Common realistic values
    users = [
        "postgres", "app_user", "webapp", "api_service", "readonly_user",
        "admin", "reporting", "analytics", "backend", "frontend",
        "john.doe", "jane_smith", "service_account_01", "etl_user", "monitoring"
    ]
    
    databases = [
        "production", "prod", "staging", "development", "dev",
        "test", "qa", "analytics", "warehouse", "reporting",
        "main", "app_production", "commerce", "inventory", "crm"
    ]
    
    timezones = ["UTC", "IST", "PST", "EST", "GMT", "+0530", "+0000", "-0700", "-0400"]
    
    # Base time - starting from few months ago
    base_time = datetime(2025, 8, 1, 0, 0, 0)
    
    logs = []
    
    for i in range(count):
        # Random time progression (mostly sequential but with some jumps)
        seconds_jump = random.choices(
            [3, 5, 8, 12, 15, 30, 45, 60, 90, 120, 300, 600],
            weights=[25, 20, 15, 12, 10, 8, 5, 3, 1, 0.5, 0.3, 0.2],
            k=1
        )[0]
        
        base_time += timedelta(seconds=seconds_jump)
        
        # Format timestamp like PostgreSQL typically does
        timestamp = base_time.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]  # up to milliseconds
        
        timezone = random.choice(timezones)
        
        # PostgreSQL PIDs are usually 5-6 digits
        pid = random.randint(12000, 98500)
        
        user = random.choices(
            users,
            weights=[10, 18, 15, 14, 8, 6, 5, 4, 12, 8, 3, 3, 4, 6, 5],  # more frequent app users
            k=1
        )[0]
        
        # Some users more often connect to specific DBs
        if user in ["postgres", "admin"]:
            db = random.choice(["postgres", "template1", "production"])
        elif user in ["reporting", "analytics"]:
            db = random.choice(["analytics", "warehouse", "reporting"])
        else:
            db = random.choice(databases)
        
        # Occasional very short or very long usernames (realistic variation)
        if random.random() < 0.03:  # 3% chance
            user = random.choice(["svc_app_001", "pg_repl", "replication", "pgbouncer"])
        elif random.random() < 0.02:
            user = f"user_{random.randint(1000,9999)}"
        
        log_line = f"{timestamp} {timezone} [{pid}] LOG:  connection authorized: user={user} database={db}"
        logs.append(log_line)
    
    return logs

def generate_postgres_statement_logs(count=1000):
    """
    Generate realistic PostgreSQL statement logs for model training
    Format: <timestamp> <timezone> [<pid>] STATEMENT: <SQL_STATEMENT>;
    """
    # Common values used in queries
    tables = [
        "users", "orders", "products", "order_items", "categories",
        "customers", "payments", "sessions", "addresses", "inventory",
        "reviews", "wishlists", "coupons", "transactions", "logs", "cart"
    ]
    
    schemas = ["public", "auth", "shop", "analytics", "staging", "reporting"]
    
    timezones = ["UTC", "IST", "Asia/Kolkata", "PST", "EST", "GMT"]
    
    pids = list(range(12345, 18976)) + list(range(21000, 27890)) + list(range(30000, 38900))
    
    # Query templates with different probabilities (weights)
    query_templates = [
        ("SELECT {fields} FROM {schema}.{table} WHERE {condition}",          42),
        ("INSERT INTO {schema}.{table} ({fields}) VALUES ({values})",        18),
        ("UPDATE {schema}.{table} SET {assignments} WHERE {condition}",      14),
        ("DELETE FROM {schema}.{table} WHERE {condition}",                    7),
        ("SELECT * FROM {schema}.{table} ORDER BY {order_field} LIMIT {limit}", 6),
        ("SELECT count(*) FROM {schema}.{table}",                             5),
        ("BEGIN",                                                             3),
        ("COMMIT",                                                            3),
        ("ROLLBACK",                                                          2),
    ]
    
    # All possible columns that might appear
    columns = [
        "id", "user_id", "order_id", "product_id", "session_id",
        "email", "phone", "status", "created_at", "updated_at",
        "amount", "quantity", "price", "total", "name", "description",
        "is_active", "deleted_at", "last_login", "ip_address"
    ]
    
    # Common WHERE conditions
    condition_templates = [
        "id = {val}",
        "user_id = {val}",
        "order_id = {val}",
        "status = 'active'",
        "status = 'completed'",
        "status = 'pending'",
        "created_at >= '2025-01-01'",
        "created_at > NOW() - INTERVAL '30 days'",
        "email = 'user_{val}@example.com'",
        "deleted_at IS NULL",
        "amount >= 500",
        "amount <= 9999.99"
    ]
    
    base_time = datetime(2025, 9, 15, 0, 0, 0)
    logs = []
    
    for _ in range(count):
        # Advance time irregularly (queries don't come perfectly evenly)
        base_time += timedelta(
            seconds=random.randint(1, 60),
            milliseconds=random.randint(0, 999)
        )
        
        timestamp = base_time.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
        tz = random.choice(timezones)
        pid = random.choice(pids)
        
        # Choose query template according to weights
        template, _ = random.choices(
            query_templates,
            weights=[w for _, w in query_templates],
            k=1
        )[0]
        
        schema = random.choice(schemas)
        table = random.choice(tables)
        
        # Generate different parts depending on query type
        if "{fields}" in template:
            field_count = random.choices([1,2,3,4,5,6], weights=[6,22,35,24,9,4])[0]
            fields = ", ".join(random.sample(columns, min(field_count, len(columns))))
        else:
            fields = ""
            
        if "{condition}" in template:
            cond_t = random.choice(condition_templates)
            val = random.randint(100000, 9999999)
            condition = cond_t.format(val=val)
        else:
            condition = ""
            
        if "{assignments}" in template:
            count = random.randint(1, 4)
            assignments = ", ".join(
                f"{random.choice(columns)} = {random.choice([
                    'NULL', 
                    str(random.randint(1,999999)),
                    f"'{random.choice(['active','pending','completed','cancelled'])}'",
                    f"'2025-{random.randint(10,12):02d}-{random.randint(1,28):02d} 14:30:00'",
                    'true', 'false'
                ])}"
                for _ in range(count)
            )
        else:
            assignments = ""
            
        if "{values}" in template:
            count = random.randint(2, 7)
            values = ", ".join(
                random.choice([
                    'DEFAULT', 
                    str(random.randint(100,999999)),
                    f"'user_{random.randint(1000,9999)}@example.com'",
                    f"'{random.choice(['active','pending','shipped','delivered'])}'",
                    "NOW()",
                    "true", "false",
                    f"'2025-{random.randint(10,12):02d}-{random.randint(1,28):02d} 10:45:22'"
                ]) for _ in range(count)
            )
        else:
            values = ""
            
        if "{order_field}" in template:
            order_field = random.choice(columns)
        else:
            order_field = ""
            
        if "{limit}" in template:
            limit = random.choice([10, 20, 25, 50, 100, 500])
        else:
            limit = ""
        
        sql = template.format(
            fields=fields,
            schema=schema,
            table=table,
            condition=condition,
            assignments=assignments,
            values=values,
            order_field=order_field,
            limit=limit
        ).strip()
        
        # Clean up whitespace
        sql = " ".join(sql.split())
        
        # Add semicolon to statements (not to BEGIN/COMMIT/ROLLBACK)
        if sql not in ["BEGIN", "COMMIT", "ROLLBACK"]:
            sql += ";"
        
        log_line = f"{timestamp} {tz} [{pid}] STATEMENT: {sql}"
        logs.append(log_line)
    
    return logs

# ============================================================================
# ORACLE LOG GENERATORS
# ============================================================================


def generate_oracle_alert_logs(count=1000):
    """
    Generate realistic-looking Oracle alert log entries
    Format: <timestamp> ORA-<error_code>: <error_message>
    """
    # Common Oracle error codes that frequently appear in alert logs
    ora_errors = [
        (31, "ORA-00031: session marked for kill"),
        (40, "ORA-00040: active time limit exceeded - call aborted"),
        (60, "ORA-00060: deadlock detected while waiting for resource"),
        (7445, "ORA-07445: exception encountered: core dump [{func}] [{sig}] [...]"),
        (1652, "ORA-01652: unable to extend temp segment by {size} in tablespace {tablespace}"),
        (1653, "ORA-01653: unable to extend table {owner}.{table} by {blocks} in tablespace {tablespace}"),
        (1654, "ORA-01654: unable to extend index {owner}.{index} by {blocks} in tablespace {tablespace}"),
        (1688, "ORA-01688: unable to extend table {owner}.{table} partition {partition} by {blocks} in tablespace {tablespace}"),
        (19815, "ORA-19815: WARNING: db_recovery_file_dest_size of {size_mb} bytes is 100.00% used, and has {remaining} remaining bytes available."),
        (4031, "ORA-04031: unable to allocate {bytes} bytes of shared memory (\"{area}\",\"{object}\",\"{type}\")"),
        (12505, "ORA-12505: TNS:listener does not currently know of SID given in connect descriptor"),
        (12514, "ORA-12514: TNS:listener does not currently know of service requested in connect descriptor"),
        (12560, "ORA-12560: TNS:protocol adapter error"),
        (27101, "ORA-27101: shared memory realm does not exist"),
        (10878, "ORA-10878: parallel recovery slave died unexpectedly"),
        (600, "ORA-00600: internal error code, arguments: [{arg1}], [{arg2}], [{arg3}], [{arg4}], [{arg5}], [{arg6}]"),
        (7444, "ORA-07444: memory allocation error - requested {bytes} bytes, got {actual}"),
        (1578, "ORA-01578: ORACLE data block corrupted (file # {file}, block # {block})"),
        (1119, "ORA-01119: error in creating database file '{file}'"),
        (1104, "ORA-01104: invalid number of control files"),
        (17629, "ORA-17629: Cannot connect to the remote database server"),
        (28000, "ORA-28000: the account is locked"),
        (28001, "ORA-28001: the password has expired"),
        (1017, "ORA-01017: invalid username/password; logon denied"),
        (2395, "ORA-002395: mount destination is already in use"),
    ]
    
    owners = ["SYS", "APPUSER", "HR", "SALES", "FINANCE", "DATAWARE", "ODS", "ETL"]
    tables = ["TRANSACTIONS", "CUSTOMERS", "ORDERS", "INVOICES", "PAYMENTS", "LOGINS", "AUDIT_LOG", "POSITIONS"]
    indexes = ["PK_TRANSACTIONS", "IDX_CUST_EMAIL", "ORD_DATE_IDX", "INV_STAT_IDX", "PAY_CUST_IDX"]
    tablespaces = ["USERS", "DATA", "INDEXES", "TEMP", "UNDOTBS1", "BIG_DATA", "ARCHIVE"]
    partitions = ["P202501", "P202502", "P_Q1_2026", "P_JAN_26", "P_2026_01"]
    shared_areas = ["shared pool", "large pool", "java pool", "streams pool"]
    object_types = ["sql area", "library cache", "free memory", "KGH: heap"]
    
    # Exactly 25 weights matching the 25 ora_errors above
    weights = [
        15,  # 00031 session marked for kill
        8,   # 00040 time limit
        40,  # 00060 deadlock ★ very common
        25,  # 07445 core dump
        22,  # 01652 temp space
        22,  # 01653 table extend
        20,  # 01654 index extend
        12,  # 01688 partitioned table
        18,  # 19815 FRA full
        35,  # 04031 shared pool ★ very common
        10,  # 12505 listener SID
        10,  # 12514 listener service
        12,  # 12560 protocol adapter
        9,   # 27101 shared memory realm
        6,   # 10878 parallel recovery
        45,  # 00600 internal error ★ most common
        7,   # 07444 memory alloc
        8,   # 01578 block corrupted
        4,   # 01119 create datafile
        4,   # 01104 controlfiles
        5,   # 17629 remote connect
        6,   # 28000 account locked
        7,   # 28001 password expired
        9,   # 01017 login failed
        3    # 002395 mount destination
    ]
    
    base_time = datetime(2025, 10, 1, 0, 0, 0)
    logs = []
    
    for _ in range(count):
        base_time += timedelta(seconds=random.randint(5, 480))
        # Oracle alert log timestamps usually look like this (no timezone usually)
        timestamp = base_time.strftime("%a %b %d %H:%M:%S %Y")
        
        error_code, template = random.choices(ora_errors, weights=weights, k=1)[0]
        
        # Generate realistic message
        if "{size}" in template and "temp segment" in template:
            size = random.randint(8, 1024) * 128
            msg = template.format(size=size, tablespace=random.choice(tablespaces))
        elif "{size_mb}" in template:
            msg = template.format(
                size_mb=random.randint(100000, 4000000),
                remaining=random.randint(1000000, 8000000)
            )
        elif "{bytes}" in template and "shared memory" in template:
            msg = template.format(
                bytes=random.choice([1024, 4096, 8192, 16384, 32768, 65536, 131072]),
                area=random.choice(shared_areas),
                object=random.choice(object_types),
                type=random.choice(["permanent", "freeable", ""])
            )
        elif "{bytes}" in template and "memory allocation" in template:
            msg = template.format(
                bytes=random.choice([1024, 4096, 8192, 16384, 32768, 65536, 131072]),
                actual=random.choice([0, 512, 1024, 2048, 4096])
            )
        elif "{owner}" in template or "{table}" in template or "{index}" in template:
            msg = template.format(
                owner=random.choice(owners),
                table=random.choice(tables),
                index=random.choice(indexes),
                tablespace=random.choice(tablespaces),
                blocks=random.randint(8, 512),
                size=random.randint(8, 1024) * 128,
                partition=random.choice(partitions + [""])
            )
        elif "00600" in template:
            args = [hex(random.randint(0, 0xFFFFFFFF))[2:].upper().zfill(8) for _ in range(6)]
            msg = template.format(
                arg1=args[0], arg2=args[1], arg3=args[2],
                arg4=args[3], arg5=args[4], arg6=args[5]
            )
        elif "{file}" in template and "{block}" in template:
            msg = template.format(file=random.randint(1, 512), block=random.randint(10000, 9999999))
        elif "{file}" in template:
            msg = template.format(file=f"/u01/app/oracle/oradata/PROD/datafile_{random.randint(1, 512)}.dbf")
        elif "{func}" in template:
            msg = template.format(
                func=random.choice(["kghalo", "kghfr", "kksfbc", "qerixAllocate", "kxfxgncl"]),
                sig=random.choice(["11", "6", "7", "SIGSEGV", "SIGBUS"])
            )
        else:
            msg = template
        
        log_line = f"{timestamp:<25}\n{msg}"
        logs.append(log_line)
    
    return logs

def generate_oracle_listener_logs(count=1000):
    """Generate Oracle listener logs based on the provided template"""
    service_names = [
        "orcl", "pdb1", "salesdb", "hrdb", "testdb", "financedb", "inventory", "warehouse",
        "prod", "devdb", "staging", "backupdb", "analytics", "reporting", "crmdb", "erpdb"
    ]
    error_statuses = [12505, 12514, 12541, 12170, 12560, 12537, 12528, 12519]
    
    logs = []
    base_time = datetime(2026, 1, 1, 0, 0, 0)
    
    for i in range(count):
        # Add random interval for timestamp variety (1-60 seconds for high volume server feel)
        base_time += timedelta(seconds=random.randint(1, 60))
        
        # Format timestamp like Oracle: DD-MMM-YYYY HH:MI:SS (month in uppercase)
        day = base_time.strftime("%d")
        month = base_time.strftime("%b").upper()
        year = base_time.strftime("%Y")
        time_str = base_time.strftime("%H:%M:%S")
        timestamp = f"{day}-{month}-{year} {time_str}"
        
        # Random service
        service = random.choice(service_names)
        
        # Random IP (mix of private and public for realism)
        if random.random() < 0.7:  # Mostly private IPs
            ip = f"192.168.{random.randint(0, 255)}.{random.randint(1, 255)}"
        elif random.random() < 0.5:
            ip = f"10.{random.randint(0, 255)}.{random.randint(0, 255)}.{random.randint(1, 255)}"
        else:
            ip = '.'.join(str(random.randint(0, 255)) for _ in range(4))  # Public-like
        
        # Random port
        port = random.randint(1024, 65535)
        
        # Status: mostly success (0), but some errors for realism
        if random.random() < 0.85:  # 85% success rate
            status = 0
        else:
            status = random.choice(error_statuses)
        
        # Format the log
        log = f"{timestamp} * (CONNECT_DATA=(SERVICE_NAME={service})) * (ADDRESS=(PROTOCOL=tcp)(HOST={ip})(PORT={port})) * establish * {service} * {status}"
        logs.append(log)
    
    return logs


def generate_oracle_audit_logs(count=1000):
    """Generate Oracle audit logs based on the provided template"""
    action_templates = [
        "SELECT",
        "INSERT",
        "UPDATE",
        "DELETE",
        "CREATE TABLE",
        "CREATE VIEW",
        "CREATE PROCEDURE",
        "CREATE INDEX",
        "CREATE USER",
        "CREATE ROLE",
        "DROP TABLE",
        "DROP VIEW",
        "DROP PROCEDURE",
        "DROP INDEX",
        "DROP USER",
        "DROP ROLE",
        "ALTER TABLE",
        "ALTER VIEW",
        "ALTER PROCEDURE",
        "ALTER INDEX",
        "ALTER USER",
        "ALTER ROLE",
        "GRANT",
        "REVOKE",
        "EXECUTE",
        "LOGON",
        "LOGOFF",
        "AUDIT",
        "NOAUDIT",
        "ANALYZE",
        "COMMENT",
        "RENAME",
        "TRUNCATE",
        "FLASHBACK",
        "PURGE",
    ]
    users = [
        "SYS", "SYSTEM", "DBSNMP", "OUTLN", "HR", "OE", "PM", "IX", "SH", "BI",
        "SCOTT", "ADMIN", "APPUSER", "WEBUSER", "DBA", "ANALYST", "DEVELOPER",
        "TESTER", "GUEST", "BACKUP", "AUDITOR", "REPLICATOR", "MONITOR",
    ] + ["USER_" + str(i).zfill(3) for i in range(1, 201)]  # More users for variety
    objects = [
        "EMPLOYEES", "DEPARTMENTS", "LOCATIONS", "JOBS", "JOB_HISTORY",
        "COUNTRIES", "REGIONS", "ORDERS", "ORDER_ITEMS", "PRODUCTS",
        "CUSTOMERS", "INVENTORIES", "WAREHOUSES", "SALES", "COSTS",
        "ACCOUNTS", "TRANSACTIONS", "LOGS", "SESSIONS", "AUDIT_TRAIL",
        "CONFIG", "SETTINGS", "USERS", "ROLES", "PERMISSIONS",
    ] + ["OBJ_" + str(i).zfill(4) for i in range(1, 501)]  # More objects for big server feel
    logs = []
    base_time = datetime(2023, 1, 1, 0, 0, 0)  # Start a year back for temporal spread
    for i in range(count):
        # Random gaps: small for bursts, larger for spreads, simulating busy server periods
        gap_seconds = random.choice([
            random.randint(1, 60),  # Frequent actions
            random.randint(60, 600),  # Medium
            random.randint(600, 3600),  # Hourly
            random.randint(3600, 86400),  # Daily spikes
        ])
        base_time += timedelta(seconds=gap_seconds)
        # Oracle-like timestamp format for authenticity
        timestamp = base_time.strftime("%d-%b-%Y %H:%M:%S")
        action = random.choice(action_templates)
        user = random.choice(users)
        # For session actions like LOGON/LOGOFF, obj might be empty or special
        if action in ["LOGON", "LOGOFF"]:
            obj_name = random.choice(["", "SESSION", "DATABASE"])
        else:
            obj_name = random.choice(objects)
        # Add some randomness: occasionally add schema prefix for realism
        if random.random() < 0.3 and obj_name:  # 30% chance
            schema = random.choice(["HR.", "OE.", "PM.", "SYS.", "APP.", ""])
            obj_name = schema + obj_name
        # Build the log string with template, including trailing newlines for separation
        log = f"""Audit record generated at {timestamp}
ACTION : {action}
USERID : {user}
OBJ$NAME : {obj_name}"""
        logs.append(log)
    # Shuffle slightly to simulate unsorted log dumps, but keep mostly chronological
    if random.random() < 0.1:  # Rare full shuffle for variety in batches
        random.shuffle(logs)
    return logs

# ============================================================================
# SQL SERVER LOG GENERATORS
# ============================================================================

def generate_sql_server_error_logs(count=1000):
    """Generate SQL Server error logs"""
    error_templates = [
        (8134, 16, "Divide by zero error encountered."),
        (2627, 14, "Violation of PRIMARY KEY constraint '{constraint}'. Cannot insert duplicate key in object '{database}.{table}'. The duplicate key value is ({value})."),
        (547, 16, "The {action} statement conflicted with the {constraint_type} constraint '{constraint}'. The conflict occurred in database '{database}', table '{database}.{table}', column '{column}'."),
        (208, 16, "Invalid object name '{database}.{table}'."),
        (207, 16, "Invalid column name '{column}'."),
        (8152, 16, "String or binary data would be truncated. The statement has been terminated."),
        (229, 14, "The {permission} permission was denied on the object '{table}', database '{database}', schema 'dbo'."),
        (2812, 16, "Could not find stored procedure '{proc}'."),
        (1205, 13, "Transaction (Process ID {proc_id}) was deadlocked on lock resources with another process and has been chosen as the deadlock victim. Rerun the transaction."),
        (1222, 16, "Lock request time out period exceeded. The statement has been terminated."),
        (4060, 11, "Cannot open database '{database}' requested by the login. The login failed."),
        (18456, 14, "Login failed for user '{user}'.{reason}"),
        (3621, 0, "The statement has been terminated."),
        (17, 20, "SQL Server does not exist or access denied."),
        (701, 17, "There is insufficient system memory to run this query."),
        (4861, 16, "Cannot bulk load because the file '{file}' could not be opened. Operating system error code {os_error}."),
    ]
    tables = ["Users", "Orders", "Products", "Customers", "Invoices", "Sessions", "Logs", "Transactions", "Employees", "Departments"]
    databases = ["AdventureWorks", "Northwind", "Contoso", "MyDatabase", "ProductionDB", "StagingDB", "TestDB", "EcommerceDB"]
    columns = ["ID", "Name", "Email", "CreatedDate", "Status", "Amount", "Price", "Quantity", "Address", "Phone"]
    constraints = ["PK_Users", "UQ_Email", "FK_Order_Customer", "CK_Status", "IX_Name", "PK_Orders", "FK_Product_Category"]
    procs = ["usp_GetUser", "sp_UpdateOrder", "proc_ProcessPayment", "GetAllCustomers", "InsertLog", "UpdateInventory"]
    users = ["sa", "dbuser", "app_service", "webapp", "guest", "admin", "report_user", "backup_operator"]
    actions = ["INSERT", "UPDATE", "DELETE", "MERGE"]
    constraint_types = ["FOREIGN KEY", "CHECK", "UNIQUE"]
    permissions = ["SELECT", "INSERT", "UPDATE", "DELETE", "EXECUTE"]
    reasons = [" Reason: Failed to open the explicitly specified database '{database}'.", " Reason: Password did not match that for the login provided.", " Reason: Account is locked out.", ""]
    files = ["C:\\data\\bulk.csv", "D:\\imports\\data.txt", "/var/sql/bulk.dat"]
    os_errors = ["5(Access is denied.)", "3(The system cannot find the path specified.)", "2(The system cannot find the file specified.)"]
    logs = []
    base_time = datetime(2024, 1, 1, 0, 0, 0)
    for i in range(count):
        base_time += timedelta(seconds=random.randint(60, 1800))  # Wider range for more spread out times, simulating busy server over days
        timestamp = base_time.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
        error_code, severity, template = random.choice(error_templates)
        state = random.randint(1, 255)
        format_dict = {
            "table": random.choice(tables),
            "database": random.choice(databases),
            "column": random.choice(columns),
            "constraint": random.choice(constraints),
            "proc": random.choice(procs),
            "proc_id": random.randint(50, 500),
            "user": random.choice(users),
            "action": random.choice(actions),
            "constraint_type": random.choice(constraint_types),
            "permission": random.choice(permissions),
            "reason": random.choice(reasons),
            "value": str(random.randint(1, 99999)) if random.random() < 0.5 else f"'{''.join(random.choices('abcdefghijklmnopqrstuvwxyz', k=8))}'",
            "file": random.choice(files),
            "os_error": random.choice(os_errors),
        }
        msg = template.format(**format_dict)
        spid = f"spid{random.randint(1, 2000)}{random.choice(['', 's', 'u', 'r'])}" if random.random() < 0.8 else "Logon"  # Add variety with occasional different process info
        logs.append(f"{timestamp} {spid} Server Error: {error_code}, Severity: {severity}, State: {state}. {msg}")
    return logs


def generate_sql_server_audit_logs(count=1000):
    """Generate SQL Server audit logs based on the provided template."""
    logs = []
    
    # Action IDs and corresponding base templates for variety
    action_templates = [
        ('SL', "SELECT * FROM {table}"),
        ('SL', "SELECT {columns} FROM {table}"),
        ('SL', "SELECT {columns} FROM {table} WHERE {condition}"),
        ('SL', "SELECT {columns} FROM {table} ORDER BY {order_col} {order_dir}"),
        ('SL', "SELECT TOP {top_num} {columns} FROM {table}"),
        ('IN', "INSERT INTO {table} ({columns}) VALUES ({values})"),
        ('IN', "INSERT INTO {table} SELECT {columns} FROM {source_table}"),
        ('UP', "UPDATE {table} SET {set_clause} WHERE {condition}"),
        ('UP', "UPDATE {table} SET {set_clause}"),
        ('DL', "DELETE FROM {table} WHERE {condition}"),
        ('DL', "DELETE FROM {table}"),
        ('EX', "EXEC {proc_name}"),
        ('EX', "EXEC {proc_name} {params}"),
        ('CR', "CREATE TABLE {table} ({col_defs})"),
        ('AL', "ALTER TABLE {table} ADD {column_def}"),
        ('DR', "DROP TABLE {table}"),
        ('LG', "LOGIN {user}"),
        ('DB', "USE {db}"),
    ]
    
    # Expanded lists for variety to simulate a large server environment
    users = [
        'sa', 'admin', 'app_user', 'dbo', 'guest', 'web_service', 'batch_processor', 'report_generator',
        'data_analyst', 'backup_user', 'monitoring_tool', 'etl_job', 'api_user', 'readonly_user',
        'developer', 'qa_tester', 'sysadmin', 'security_auditor', 'replication_user', 'anonymous'
    ]
    
    databases = [
        'master', 'tempdb', 'model', 'msdb', 'production_db', 'staging_db', 'test_db', 'analytics_db',
        'warehouse', 'crm_system', 'erp_db', 'logging_db', 'user_data', 'financials', 'hr_system',
        'inventory_db', 'sales_db', 'marketing', 'backup_db', 'archive'
    ]
    
    tables = [
        'users', 'orders', 'products', 'customers', 'employees', 'sessions', 'payments', 'inventory',
        'logs', 'audit_trail', 'transactions', 'invoices', 'shipments', 'reviews', 'categories',
        'suppliers', 'departments', 'roles', 'permissions', 'configurations', 'metrics', 'reports'
    ]
    
    columns = [
        'id', 'user_id', 'name', 'email', 'password_hash', 'created_at', 'updated_at', 'status',
        'price', 'quantity', 'description', 'order_date', 'total_amount', 'customer_id', 'product_id',
        'employee_id', 'department_id', 'role_id', 'login_time', 'ip_address', 'error_code'
    ]
    
    proc_names = [
        'sp_who', 'sp_help', 'usp_get_users', 'usp_update_order', 'sp_execute_sql', 'usp_insert_log',
        'sp_lock', 'usp_delete_record', 'sp_helpdb', 'usp_report_generate', 'sp_monitor', 'usp_batch_process'
    ]
    
    order_dirs = ['ASC', 'DESC']
    
    statuses = ['active', 'inactive', 'pending', 'completed', 'failed', 'processing', 'archived']
    
    base_time = datetime(2023, 1, 1, 0, 0, 0)  # Start from a past date for realism
    
    for i in range(count):
        # Increment time randomly to simulate ongoing activity (1-1200 seconds for spread over hours/days)
        base_time += timedelta(seconds=random.randint(1, 1200))
        timestamp = base_time.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]  # Timestamp with milliseconds
        
        # Choose random elements
        action_id, template = random.choice(action_templates)
        user = random.choice(users)
        db = random.choice(databases)
        table = random.choice(tables)
        
        # Generate dynamic parts based on template
        replacements = {
            'table': table,
            'db': db,
            'user': user,
        }
        
        if '{columns}' in template:
            selected_cols = random.sample(columns, random.randint(1, 5))
            replacements['columns'] = ', '.join(selected_cols)
        
        if '{condition}' in template:
            cond_col = random.choice(columns)
            if 'id' in cond_col or 'quantity' in cond_col or 'amount' in cond_col:
                cond_val = random.randint(1, 100000)
            elif 'date' in cond_col or 'time' in cond_col:
                cond_val = f"'{base_time.strftime('%Y-%m-%d')}'"  # Random date-like
            else:
                cond_val = f"'{random.choice(statuses)}'"
            replacements['condition'] = f"{cond_col} = {cond_val}"
        
        if '{set_clause}' in template:
            set_parts = []
            for _ in range(random.randint(1, 3)):
                set_col = random.choice(columns)
                if 'id' in set_col or 'quantity' in set_col or 'amount' in set_col:
                    set_val = random.randint(1, 100000)
                elif 'date' in set_col or 'time' in set_col:
                    set_val = f"'{base_time.strftime('%Y-%m-%d')}'"
                else:
                    set_val = f"'{random.choice(statuses + ['updated_value', 'new_data', 'modified'])}'"
                set_parts.append(f"{set_col} = {set_val}")
            replacements['set_clause'] = ', '.join(set_parts)
        
        if '{values}' in template:
            cols = random.sample(columns, random.randint(2, 6))
            values = []
            for col in cols:
                if 'id' in col or 'quantity' in col or 'amount' in col:
                    values.append(str(random.randint(1, 100000)))
                elif 'date' in col or 'time' in col:
                    values.append(f"'{base_time.strftime('%Y-%m-%d %H:%M:%S')}'")
                else:
                    values.append(f"'{random.choice(['sample_data', 'test_value', 'random_entry', 'new_record'])}'")
            replacements['columns'] = ', '.join(cols)
            replacements['values'] = ', '.join(values)
        
        if '{source_table}' in template:
            replacements['source_table'] = random.choice(tables)
        
        if '{order_col}' in template:
            replacements['order_col'] = random.choice(columns)
            replacements['order_dir'] = random.choice(order_dirs)
        
        if '{top_num}' in template:
            replacements['top_num'] = random.randint(1, 100)
        
        if '{proc_name}' in template:
            replacements['proc_name'] = random.choice(proc_names)
        
        if '{params}' in template:
            param_parts = []
            for _ in range(random.randint(1, 3)):
                param_name = random.choice(['@id', '@name', '@status', '@date'])
                if '@id' in param_name:
                    param_val = random.randint(1, 100000)
                elif '@date' in param_name:
                    param_val = f"'{base_time.strftime('%Y-%m-%d')}'"
                else:
                    param_val = f"'{random.choice(statuses)}'"
                param_parts.append(f"{param_name} = {param_val}")
            replacements['params'] = ', '.join(param_parts)
        
        if '{col_defs}' in template:
            col_def_parts = []
            for _ in range(random.randint(2, 5)):
                col_name = random.choice(columns)
                col_type = random.choice(['INT', 'VARCHAR(255)', 'DATETIME', 'DECIMAL(10,2)', 'BIT'])
                col_def_parts.append(f"{col_name} {col_type}")
            replacements['col_defs'] = ', '.join(col_def_parts)
        
        if '{column_def}' in template:
            col_name = random.choice(columns)
            col_type = random.choice(['INT', 'VARCHAR(255)', 'DATETIME', 'DECIMAL(10,2)'])
            replacements['column_def'] = f"{col_name} {col_type}"
        
        # Format the statement
        statement = template.format(**replacements)
        
        # Occasionally add complexity like joins or subqueries for realism (10% chance)
        if random.random() < 0.1:
            join_table = random.choice(tables)
            join_col1 = random.choice(columns)
            join_col2 = random.choice(columns)
            statement = f"{statement} INNER JOIN {join_table} ON {table}.{join_col1} = {join_table}.{join_col2}"
        elif random.random() < 0.05:
            statement = f"({statement}) UNION ({template.format(**replacements)})"
        
        # Escape any single quotes in statement for log safety (simulate real log escaping)
        statement = statement.replace("'", "''")
        
        # Additional fields to simulate large server logs: add sequence_id and host for variety
        sequence_id = random.randint(1000000, 999999999)  # Large sequence for big server feel
        host_name = random.choice(['SERVER01', 'DB_CLUSTER_NODE2', 'PROD_SERVER_3', 'AZURE_VM_4', 'AWS_INSTANCE_5'])
        
        # Construct the log entry
        log = f"{timestamp} sequence_id={sequence_id} host={host_name} action_id={action_id} session_server_principal_name={user} database_name={db} statement={statement}"
        
        logs.append(log)
    
    return logs


def generate_sql_server_transaction_logs(count=1000):
    """
    Generate realistic-looking SQL Server transaction log entries 
    based on the template: LSN: (<file>:<offset>:<slot>) Operation: <operation_type>
    Suitable for training ML models on transaction log patterns.
    """
    logs = []
    
    # Common transaction log operation types in SQL Server
    operation_types = [
        "LOP_INSERT_ROWS",
        "LOP_DELETE_ROWS",
        "LOP_MODIFY_ROW",
        "LOP_BEGIN_XACT",
        "LOP_COMMIT_XACT",
        "LOP_ABORT_XACT",
        "LOP_MARK_DDL",
        "LOP_HOBT_DDL",
        "LOP_CREATE_INDEX",
        "LOP_DROP_INDEX",
        "LOP_SORT",
        "LOP_GAM_ALLOCATE",
        "LOP_SGAM_ALLOCATE",
        "LOP_PFS_ALLOCATE",
        "LOP_PAGE_SPLIT",
        "LOP_PAGE_MERGE",
        "LOP_FILE_HDR_MODIFY",
        "LOP_FORMAT_PAGE",
        "LOP_ROOT_CHANGE",
        "LOP_LOCK_XID",
        "LOP_LOCK_ROW",
        "LOP_LOCK_TABLE",
        "LOP_BULK_LOAD",
        "LOP_INDEX_LEAF",
        "LOP_INDEX_INTERIOR",
        "LOP_SET_BITS",
        "LOP_CLR",
        "LOP_BEGIN_CKPT",
        "LOP_END_CKPT",
        "LOP_XACT_CKPT"
    ]
    
    # Context-aware operation groups (to make patterns more realistic)
    begin_ops = ["LOP_BEGIN_XACT", "LOP_BEGIN_CKPT"]
    commit_ops = ["LOP_COMMIT_XACT", "LOP_END_CKPT"]
    ddl_ops = ["LOP_MARK_DDL", "LOP_HOBT_DDL", "LOP_CREATE_INDEX", "LOP_DROP_INDEX"]
    allocation_ops = ["LOP_GAM_ALLOCATE", "LOP_SGAM_ALLOCATE", "LOP_PFS_ALLOCATE", "LOP_FORMAT_PAGE"]
    row_ops = ["LOP_INSERT_ROWS", "LOP_DELETE_ROWS", "LOP_MODIFY_ROW"]
    
    # Realistic file IDs (most systems have few data/log files)
    file_ids = [1, 2, 3, 4, 5]  # 1-2 most common for data, 2-3 for log usually
    
    base_time = datetime(2024, 6, 1, 0, 0, 0)
    
    current_lsn_file = 1
    current_lsn_offset = 100000
    
    for i in range(count):
        # Time progression - realistic busy server (50ms to 3s between entries)
        base_time += timedelta(milliseconds=random.randint(50, 3000))
        timestamp = base_time.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
        
        # LSN progression - realistic increment pattern
        if random.random() < 0.12:  # occasional file rollover simulation
            current_lsn_file = random.choice(file_ids)
            current_lsn_offset = random.randint(10000, 500000)
        else:
            current_lsn_offset += random.randint(128, 8192) * 8  # typical page-aligned increments
        
        slot = random.randint(0, 15)  # realistic slot numbers are small
        
        lsn_str = f"({current_lsn_file}:{current_lsn_offset}:{slot})"
        
        # Choose operation with some realistic context/sequence bias
        if i % 50 == 0:  # occasional checkpoints
            operation = "LOP_BEGIN_CKPT" if random.random() < 0.6 else "LOP_END_CKPT"
        elif i % 17 == 0:  # occasional transaction beginnings
            operation = random.choice(begin_ops)
        elif i % 13 == 0:  # more frequent commits than aborts
            operation = random.choice(commit_ops) if random.random() < 0.85 else "LOP_ABORT_XACT"
        elif random.random() < 0.35:  # frequent row operations
            operation = random.choice(row_ops)
        elif random.random() < 0.20:  # allocation operations
            operation = random.choice(allocation_ops)
        elif random.random() < 0.12:  # DDL operations less frequent
            operation = random.choice(ddl_ops)
        else:
            operation = random.choice(operation_types)
        
        # Add realistic variation in formatting (some real logs have extra spaces)
        extra_space = "  " if random.random() < 0.3 else " "
        
        # Sometimes add context ID or XID simulation (common in real logs)
        context_addition = ""
        if random.random() < 0.45:
            xid = random.randint(100000, 999999999)
            context_addition = f"   Context: transaction id = {xid}"
        elif random.random() < 0.25:
            spid = random.randint(52, 320)
            context_addition = f"   SPID: {spid}"
        
        # Create log line
        log_line = f"{timestamp}{extra_space}LSN: {lsn_str}{extra_space}Operation: {operation}{context_addition}"
        
        logs.append(log_line)
    
    return logs

# ============================================================================
# MONGODB LOG GENERATORS
# ============================================================================

def generate_mongodb_server_logs(count=1000):
    """
    Generate realistic MongoDB server logs in JSON format
    Suitable for training ML models on large-scale production systems
    """
    logs = []
    
    # Common MongoDB severity levels (realistic distribution)
    severities = ['I'] * 65 + ['W'] * 20 + ['E'] * 10 + ['F'] * 3 + ['D'] * 2  # ~65% info, etc.
    
    # Common components (with realistic frequency weighting)
    components = (
        ['NETWORK'] * 25 +
        ['COMMAND'] * 18 +
        ['QUERY'] * 15 +
        ['WRITE'] * 12 +
        ['ACCESS'] * 8 +
        ['CONTROL'] * 6 +
        ['STORAGE'] * 5 +
        ['REPL'] * 5 +
        ['INDEX'] * 4 +
        ['SHARDING'] * 2
    )
    
    # Connection types / patterns
    conn_types = ['conn', 'conn', 'conn', 'conn', 'conn', 'conn-pool', 'accept', 'end']
    
    # Common client IPs (mix of internal, cloud, VPN ranges, etc.)
    ip_prefixes = [
        '10.', '172.16.', '192.168.',           # RFC1918 private
        '100.64.', '100.65.',                    # CGNAT
        '35.200.', '34.100.', '104.155.',        # GCP ranges
        '3.5.', '18.130.', '52.95.',             # AWS
        '13.64.', '20.190.',                     # Azure
        '45.79.', '104.237.', '172.104.'         # Linode/Vultr/etc
    ]
    
    # Common messages patterns
    message_patterns = {
        'NETWORK': [
            "client {ip}:{port} disconnected",
            "client {ip}:{port} connected",
            "client {ip}:{port} {conn_type} closed connection",
            "end connection {ip}:{port} ({reason})",
            "received client {conn_type} connection from {ip}:{port}",
            "slow network write to {ip}:{port} ({ms}ms)",
            "TLS handshake completed for {ip}:{port}"
        ],
        'COMMAND': [
            "command {db}.$cmd command: {op} {duration}ms",
            "command {db}.{coll} command: find {duration}ms",
            "command admin.$cmd command: replSetGetStatus {duration}ms",
            "command {db}.{coll} command: aggregate {duration}ms",
            "Successful command execution in {duration}ms"
        ],
        'QUERY': [
            "Slow query: {duration}ms {query_type} on {db}.{coll}",
            "query {db}.{coll} planSummary: IXSCAN {duration}ms",
            "query {db}.{coll} ntoskip:0 ntoskip:0 {duration}ms",
            "query without index {db}.{coll} {duration}ms"
        ],
        'WRITE': [
            "write concern: w: {w} acknowledged in {duration}ms",
            "insert {db}.{coll} {ninserted} documents in {duration}ms",
            "update {db}.{coll} updated {nupdated} documents",
            "remove {db}.{coll} deleted {ndeleted} documents"
        ],
        'ACCESS': [
            "Successfully authenticated as '{user}' on {db} from client {ip}:{port}",
            "Authentication failed for user '{user}' on {db} from {ip}:{port}",
            "Access control violation for user '{user}' on {db}"
        ],
        'CONTROL': [
            "MongoDB starting : pid={pid} port={port}",
            "MongoDB server version: {version}",
            "options: {options}",
            "wiredTigerStartupOptions: {wt_options}"
        ],
        'STORAGE': [
            "WiredTiger message [WT_VERB_RECOVERY] recovering",
            "WiredTiger message checkpoint took {duration}ms",
            "WiredTiger message eviction server thread started"
        ],
        'REPL': [
            "replSet info member {member} is now {state}",
            "replSet election succeeded, I am now primary",
            "replSet stepping down from primary",
            "replication lag for {member}: {lag}ms"
        ],
        'INDEX': [
            "building index {db}.{coll} on {keys}",
            "index build completed {duration}ms",
            "dropped index {db}.{coll}.{index_name}"
        ],
        'SHARDING': [
            "moveChunk data transfer progress {progress}%",
            "balancer round {round} completed in {duration}ms",
            "migrating chunk from {from} to {to}"
        ]
    }
    
    base_time = datetime(2024, 6, 1, 0, 0, 0)
    
    for i in range(count):
        base_time += timedelta(milliseconds=random.randint(10, 1800))
        
        timestamp = base_time.isoformat() + "Z"  # ISO 8601 with Z
        
        severity = random.choice(severities)
        component = random.choice(components)
        
        # Pick a realistic message for this component
        msg_template = random.choice(message_patterns.get(component, message_patterns['NETWORK']))
        
        # Generate realistic remote address
        ip_prefix = random.choice(ip_prefixes)
        ip = f"{ip_prefix}{random.randint(0,255)}.{random.randint(0,255)}"
        port = random.randint(1024, 65535)
        remote = f"{ip}:{port}"
        
        # Fill in placeholders
        replacements = {
            'ip': ip,
            'port': port,
            'conn_type': random.choice(conn_types),
            'duration': random.randint(2, 850) if 'duration' in msg_template else None,
            'ms': random.randint(150, 3200) if 'slow' in msg_template else None,
            'db': random.choice(['admin', 'config', 'local', 'app', 'prod', 'analytics', 'users', 'orders', 'logs']),
            'coll': random.choice(['sessions', 'orders', 'products', 'users', 'events', 'metrics', 'transactions']),
            'op': random.choice(['find', 'aggregate', 'count', 'distinct', 'getMore']),
            'user': random.choice(['app_svc', 'admin', 'readonly', 'etl_user', 'analytics', 'web']),
            'reason': random.choice(['normal', 'timeout', 'error', 'closed', 'killed']),
            'w': random.choice(['1', 'majority', '2', '3']),
            'ninserted': random.randint(1, 5000),
            'nupdated': random.randint(1, 1200),
            'ndeleted': random.randint(1, 800),
            'member': f"shard{random.randint(0,4)}-replset{random.randint(1,3)}",
            'state': random.choice(['PRIMARY', 'SECONDARY', 'RECOVERING', 'STARTUP2']),
            'lag': random.randint(5, 4800),
            'keys': '{ "createdAt": 1, "status": 1 }',
            'index_name': f"idx_{random.choice(['date', 'user', 'status', 'compound', 'ttl'])}"
        }
        
        # Clean up None values
        for k in list(replacements):
            if replacements[k] is None:
                del replacements[k]
        
        try:
            msg = msg_template.format(**replacements)
        except KeyError:
            msg = msg_template  # fallback if formatting fails
        
        # Build the full log entry
        log_entry = {
            "t": {"$date": timestamp},
            "s": severity,
            "c": component,
            "msg": msg,
            "attr": {
                "remote": remote
            }
        }
        
        # Occasionally add extra realistic attributes (15% chance)
        if random.random() < 0.15:
            extra_attrs = random.choice([
                {"connectionId": random.randint(10000, 999999)},
                {"client": f"driver: mongo-java-driver/{random.choice(['4.8.1', '4.11.0', '5.0.0'])}"},
                {"durationMillis": replacements.get('duration', random.randint(5, 4200))},
                {"planSummary": random.choice(['COLLSCAN', 'IXSCAN {createdAt:1}', 'SORT'])},
                {"numYields": random.randint(0, 45)}
            ])
            log_entry["attr"].update(extra_attrs)
        
        # Convert to pretty-ish JSON string (real logs are often pretty-printed)
        log_str = json.dumps(log_entry, separators=(',', ':'))
        
        logs.append(log_str)
    
    return logs

def generate_mongodb_audit_logs(count=1000):
    """
    Generate realistic-looking MongoDB audit logs in JSON format
    Suitable for training ML models on audit log patterns
    """
    logs = []
    
    # Common MongoDB audit event types (real ones + some frequent variants)
    audit_types = [
        "authenticate", "authFailure", "createUser", "dropUser", "updateUser", "dropDatabase",
        "createCollection", "dropCollection", "createIndex", "dropIndex", "renameCollection",
        "insert", "update", "remove", "find", "aggregate", "distinct", "count", "command",
        "applyOps", "replSetReconfig", "shutdown", "startup", "killOp", "killCursors",
        "createRole", "dropRole", "updateRole", "grantRolesToUser", "revokeRolesFromUser"
    ]
    
    # Common commands that appear in "param.command"
    command_types = [
        "find", "insert", "update", "delete", "aggregate", "count", "distinct", "getMore",
        "create", "createIndexes", "drop", "dropDatabase", "dropIndexes", "renameCollection",
        "collMod", "convertToCapped", "authenticate", "logout", "isMaster", "buildInfo",
        "listCollections", "listDatabases", "listIndexes", "currentOp", "killOp", "serverStatus"
    ]
    
    users = [
        "admin", "root", "app_user", "service_account", "readonly_user", "backup_user",
        "analytics", "etl_process", "web_api", "monitoring", "dev_user", "qa_tester",
        "batch_job", "report_generator", "replication_user", "shard_admin", "config_admin"
    ]
    
    databases = [
        "admin", "local", "config", "production", "staging", "test", "analytics",
        "warehouse", "logging", "users", "orders", "inventory", "crm", "erp",
        "finance", "hr", "marketing", "archive", "temp"
    ]
    
    collections = [
        "users", "orders", "products", "sessions", "transactions", "logs", "audit",
        "customers", "employees", "payments", "invoices", "shipments", "reviews",
        "inventory", "categories", "suppliers", "metrics", "events", "notifications"
    ]
    
    # For realistic timestamps - spread over ~2 years
    base_time = datetime(2024, 1, 1, 0, 0, 0)
    
    for i in range(count):
        # Progress time between 0.5 seconds and ~20 minutes (big cluster has lots of activity)
        base_time += timedelta(seconds=random.uniform(0.5, 1200))
        
        # ISO8601 timestamp with milliseconds and Z
        iso_ts = base_time.isoformat(timespec='milliseconds') + 'Z'
        
        atype = random.choice(audit_types)
        user = random.choice(users)
        db = random.choice(databases)
        
        # Most common case - simple command
        command = random.choice(command_types)
        
        # Add some realistic variations for param.command
        if random.random() < 0.25:  # 25% chance to make it more complex
            if atype in ["insert", "update", "delete", "find"]:
                collection = random.choice(collections)
                command = f"{command} {db}.{collection}"
            elif atype == "createIndexes":
                collection = random.choice(collections)
                command = f"createIndexes {db}.{collection}"
            elif atype == "aggregate":
                command = f"aggregate {db}.{random.choice(collections)}"
            elif random.random() < 0.4:
                # Some commands with options/parameters
                command = f"{command} {{ ns: \"{db}.{random.choice(collections)}\" }}"
        
        # Special cases for certain audit types
        if atype == "authenticate":
            command = f"SCRAM-SHA-256" if random.random() < 0.7 else "SCRAM-SHA-1"
        elif atype == "authFailure":
            command = f"authentication failed - mechanism: SCRAM-SHA-256"
        elif atype in ["createUser", "updateUser", "dropUser"]:
            command = f"{atype} {user}"
        elif atype == "shutdown":
            command = "shutdown server"
        elif atype == "killOp":
            command = f"killOp opId: {random.randint(1000000, 999999999)}"
        
        # Build the audit document
        audit_entry = {
            "atype": atype,
            "ts": {"$date": iso_ts},
            "users": [{"user": user, "db": db}],
            "param": {"command": command}
        }
        
        # Add extra realistic fields in ~40% of cases (big clusters often have more info)
        if random.random() < 0.40:
            extra = {}
            if random.random() < 0.65:
                extra["remote"] = f"{random.randint(10, 254)}.{random.randint(0, 255)}.{random.randint(0, 255)}.{random.randint(1, 254)}"
            if random.random() < 0.55:
                extra["client"] = f"mongos_{random.randint(1, 8)}" if random.random() < 0.4 else "mongo_shell"
            if random.random() < 0.3:
                extra["result"] = random.choice([0, 1, 13, 18, 11000, 13])  # 0=ok, 11000=duplicate key, etc.
            
            audit_entry["param"].update(extra)
        
        # Convert to compact JSON string (like in real MongoDB logs)
        log_line = json.dumps(audit_entry, separators=(',', ':'))
        
        logs.append(log_line)
    
    return logs

# ============================================================================
# MAIN EXECUTION
# ============================================================================

def main():
    
    # MySQL/MariaDB Logs
    with open('/home/utsav/ISEA/Utsav/Database Logs/logs/MySQL-Error.log',"w",newline='') as fout:
        for log in generate_mysql_error_logs(1000):
            fout.write(log)
            fout.write("\n")
               
        
    with open('/home/utsav/ISEA/Utsav/Database Logs/logs/MySQL-Query.log',"w",newline='') as fout:
        for log in generate_mysql_query_logs(1000):
            fout.write(log)
            fout.write("\n") 
        
    
    with open('/home/utsav/ISEA/Utsav/Database Logs/logs/MySQL-Slow.log',"w",newline='') as fout:
        for log in generate_mysql_slow_query_logs(1000):
            fout.write(log)
            fout.write("\n") 
    
    # PostgreSQL Logs
    with open('/home/utsav/ISEA/Utsav/Database Logs/logs/PostGre-Error.log',"w",newline='') as fout:
        for log in generate_postgresql_error_logs(1000):
            fout.write(log)
            fout.write("\n")
    
    with open('/home/utsav/ISEA/Utsav/Database Logs/logs/PostGre-Auth.log',"w",newline='') as fout:    
        for log in generate_postgres_auth_logs(1000):
            fout.write(log)
            fout.write("\n")  
        
    
    with open('/home/utsav/ISEA/Utsav/Database Logs/logs/PostGre-Statement.log',"w",newline='') as fout:    
        for log in generate_postgres_statement_logs(1000):
            fout.write(log)
            fout.write("\n")
    
    # Oracle Logs
    with open('/home/utsav/ISEA/Utsav/Database Logs/logs/Oracle-Alert.log',"w",newline='') as fout:    
        for log in generate_oracle_alert_logs(1000):
            fout.write(log)
            fout.write("\n")
    
    with open('/home/utsav/ISEA/Utsav/Database Logs/logs/Oracle-Listener.log',"w",newline='') as fout:    
        for log in generate_oracle_listener_logs(1000):
            fout.write(log)
            fout.write("\n")
    
    with open('/home/utsav/ISEA/Utsav/Database Logs/logs/Oracle-Audit.log',"w",newline='') as fout:    
        for log in generate_oracle_audit_logs(1000):
            fout.write(log)
            fout.write("\n")
    
    # SQL Server Logs
    with open('/home/utsav/ISEA/Utsav/Database Logs/logs/SQLServer-Error.log',"w",newline='') as fout:    
        for log in generate_sql_server_error_logs(1000):
            fout.write(log)
            fout.write("\n")
    
    with open('/home/utsav/ISEA/Utsav/Database Logs/logs/SQLServer-Audit.log',"w",newline='') as fout:    
        for log in generate_sql_server_audit_logs(1000):
            fout.write(log)
            fout.write("\n")
    
    with open('/home/utsav/ISEA/Utsav/Database Logs/logs/SQLServer-Transaction.log',"w",newline='') as fout:    
        for log in generate_sql_server_transaction_logs(1000):
            fout.write(log)
            fout.write("\n")
    
    # MongoDB Logs
    with open('/home/utsav/ISEA/Utsav/Database Logs/logs/MongoDB-Server.log',"w",newline='') as fout:    
        for log in generate_mongodb_server_logs(1000):
            fout.write(log)
            fout.write("\n")
    
    with open('/home/utsav/ISEA/Utsav/Database Logs/logs/MongoDB-Audit.log',"w",newline='') as fout:    
        for log in generate_mongodb_audit_logs(1000):
            fout.write(log)
            fout.write("\n")
    
    print("=" * 80)
    print("LOG GENERATION COMPLETE")
    print("=" * 80)

if __name__ == "__main__":
    main()